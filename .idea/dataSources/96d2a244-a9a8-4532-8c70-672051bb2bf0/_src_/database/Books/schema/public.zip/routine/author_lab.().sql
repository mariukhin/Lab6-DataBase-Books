create function author_lab() returns void
LANGUAGE SQL
AS $fun$
CREATE OR REPLACE FUNCTION author_lab() RETURNS void AS $$
              DECLARE
                  author_id integer;
                  authorname VARCHAR;
                  numberofbooks integer;
                  series integer;
              BEGIN
                  author_id := 1;
                  FOR author_id IN 1..2000 LOOP
                    numberofbooks :='1289'+ author_id;
                    IF author_id BETWEEN 1 AND 67 THEN
                      authorname := 'Alex';
                    ELSIF author_id BETWEEN 85 AND 259 THEN
                      authorname := 'Max';
                    ELSE 'Ivan' END IF;

                    IF author_id BETWEEN 1 AND 67 THEN
                      series := '9';
                    ELSIF author_id BETWEEN 85 AND 259 THEN
                      series := '23';
                    ELSE '13' END IF;
                    INSERT INTO author values (authorname,numberofbooks,series);
                    author_id :=author_id + 1;
                    END LOOP;
              END
            $$ LANGUAGE SQL;
$fun$;
