create function lab5_author() returns void
LANGUAGE plpgsql
AS $$
DECLARE
              authorId BIGINT;
              authorname VARCHAR;
              numofbooks INTEGER;
              series INTEGER;
            BEGIN
              authorId := 1;
              FOR i IN 1..2000 LOOP
                numofbooks :=1289 + authorId;
                IF authorId BETWEEN 1 AND 67  THEN
                  authorname := 'Alex';
                ELSIF authorId BETWEEN 85 AND 259  THEN
                  authorname := 'Max';
                ELSE authorname :='Ivan';
                END IF;

                IF authorId BETWEEN 1 AND 67 THEN
                  series := 9;
                ELSIF authorId BETWEEN 85 AND 259 THEN
                  series := 23;
                ELSE series :=13;
                END IF;
                INSERT INTO public.author values (authorId,authorname,numofbooks,series);
                authorId :=authorId + 1;
                END LOOP;
            END;
$$;
