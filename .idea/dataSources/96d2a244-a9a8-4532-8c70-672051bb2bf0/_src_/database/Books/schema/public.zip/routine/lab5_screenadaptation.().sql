create function lab5_screenadaptation() returns void
LANGUAGE plpgsql
AS $$
DECLARE
            screenadaptationId BIGINT;
            screenadaptationname VARCHAR ;
            year INTEGER;
            mark INTEGER;
            bookId BIGINT;

            BEGIN
            screenadaptationId := 1;
            year := 1900;
            FOR i IN 1..2000 LOOP
            screenadaptationname :='Monte Cristo'||screenadaptationId;
            IF screenadaptationId BETWEEN 1 AND 278 THEN
            bookId := 12;
            ELSIF screenadaptationId BETWEEN 369 AND 689 THEN
            bookId := 23;
            ELSE bookId :=11; 
            END IF;

            IF screenadaptationId BETWEEN 1 AND 392 THEN
            mark := 4;
            ELSIF screenadaptationId BETWEEN 489 AND 894 THEN
            mark := 5;
            ELSE mark :=2; 
            END IF;

            INSERT INTO public.screenadaptation values (screenadaptationId,screenadaptationname,year,mark,bookId);
            screenadaptationId :=screenadaptationId + 1;
            year :=year +1;
            END LOOP;
            END;
$$;
