create function lab5_cost() returns void
LANGUAGE plpgsql
AS $$
DECLARE
            costId BIGINT;
            number INTEGER ;
            high INTEGER;
            BEGIN
            costId := 1;
            FOR costId IN 1..2000 LOOP
            number :=130 + costId ;
            IF costId BETWEEN 1 AND 78 THEN
            high := 7;
            ELSIF costId BETWEEN 85 AND 259 THEN
            high := 9;
            ELSE high :=12; 
            END IF;
            INSERT INTO public.cost values (costId,number,high);
            costId :=costId + 1;
            END LOOP;
            END;
$$;
