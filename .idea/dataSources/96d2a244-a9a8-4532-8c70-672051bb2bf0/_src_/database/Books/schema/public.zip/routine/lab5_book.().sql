create function lab5_book() returns void
LANGUAGE plpgsql
AS $$
DECLARE
                bookId BIGINT;
                bookname VARCHAR;
                dateofpublication INTEGER;
                authorId BIGINT;
                editionId BIGINT;
                screenadaptationId BIGINT;
              BEGIN
                bookId := 1;
                /*screenadaptationId := 1;
                editionId := 1;*/
                FOR i IN 1..2000 LOOP
                  bookname := 'Hourseman'|| bookId ;
                  IF bookId BETWEEN 1 AND 67 THEN
                    dateofpublication := 1973;
                  ELSIF bookId BETWEEN 85 AND 259 THEN
                    dateofpublication := 1753;
                  ELSE dateofpublication := 1934;
                  END IF;

                  IF bookId BETWEEN 1 AND 84 THEN
                    authorId := 2;
                  ELSIF bookId BETWEEN 98 AND 389 THEN
                    authorId := 13;
                  ELSE authorId := 56; 
                  END IF;
                  IF editionId is null AND screenadaptationId is null THEN 
                  	INSERT INTO public.book values (bookId,bookname,dateofpublication,authorId);
                  ELSE
                  	INSERT INTO public.book values (bookId,bookname,dateofpublication,authorId,editionId,screenadaptationId);
                    editionId := editionId +1;
                    screenadaptationId := screenadaptationId + 1;
                  END IF;
                  bookId :=bookId + 1;
                  END LOOP;
              END;
$$;
